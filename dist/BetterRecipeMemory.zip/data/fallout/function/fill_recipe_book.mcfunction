recipe give @s *
